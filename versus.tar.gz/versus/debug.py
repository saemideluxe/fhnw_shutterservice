from flask import Flask, render_template
from flask import make_response

# global debug str
debug_str = "ee"
dc = 90

# App config.
DEBUG = False
app = Flask(__name__)
app.config.from_object(__name__)
app.config['SECRET_KEY'] = '7d441f27d441f27567d441f2b6176a'

@app.route("/debug/<path:debug_input>", methods=['GET'])
def set_debug_str(debug_input):
    global debug_str
    debug_str = debug_input
    return make_response("",200)

@app.route("/debug", methods=['GET'])
def get_debug_str():
    global debug_str
    if debug_str == "":
      return make_response("",200)
    else:
      tmp = debug_str
      debug_str = ""
      return make_response(tmp,200)

@app.route("/", methods=['GET', 'POST'])
def debug_string(): 
    global dc
    return render_template('commands.html',dc=dc)
 
if __name__ == "__main__":
    app.run()
